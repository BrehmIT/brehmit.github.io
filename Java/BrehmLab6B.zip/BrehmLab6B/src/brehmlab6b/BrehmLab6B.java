/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brehmlab6b;

/**
 *
 * @author crbrehm
 */
public class BrehmLab6B {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Shape shapes[] = new Shape[3];
        shapes[0] = new Circle("Circle");
        shapes[1] = new RightTriangle("Right Triangle");
        shapes[2] = new Rectangle("Rectangle");
        
        for (Shape shape : shapes) {
            System.out.println(shape);
            System.out.println();
        }
        
        Object objects[] = new Object[3];
        objects[0] = new Circle("Circle");
        objects[1] = new RightTriangle("Right Triangle");
        objects[2] = new Rectangle("Rectangle");
        
        for (Object object : objects) {
            System.out.println(object);
            System.out.println();
        }
    }
    
}
